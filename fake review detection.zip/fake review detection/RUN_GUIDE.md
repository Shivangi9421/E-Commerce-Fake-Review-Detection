# How to Run the Fake Review Detection Project

Follow these steps one by one to set up and run the project on your machine.

## Prerequisites
- You need **Python 3.8+** installed.

## Step 1: Open Terminal and Navigate
Open your command prompt (cmd) or PowerShell and navigate to the project folder:
```bash
cd "c:\Users\shiva\OneDrive\Desktop\fake review detection"
```

## Step 2: Install Dependencies
It is best to install the required libraries. Run this command:
```bash
pip install -r requirements.txt
```
*If that fails or gives permission errors, try:* `python -m pip install -r requirements.txt`

## Step 3: Run the Application
The main way to use the project is the Streamlit Dashboard.
Run this command:
```bash
python -m streamlit run app/app_streamlit.py
```
*Note: We use `python -m streamlit` instead of just `streamlit` to avoid "command not found" errors.*

The app should open in your browser automatically at `http://localhost:8501`.

## Step 4: (Optional) Retrain Models
If you want to re-train the AI models yourself:

**To train the standard Machine Learning model (Random Forest):**
```bash
python src/train_model.py
```

**To train the Deep Learning model (LSTM):**
```bash
python src/train_lstm.py
```
*(Note: This requires TensorFlow, which handles the deep learning part).*

## Troubleshooting
- **"streamlit is not recognized"**: Use `python -m streamlit run ...` as shown in Step 3.
- **"Module not found"**: Run Step 2 again to ensure all requirements are installed.
