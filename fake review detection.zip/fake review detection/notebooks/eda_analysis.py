# %% [markdown]
# # Exploratory Data Analysis (EDA) - Fake Review Detection
# This notebook explores the dataset to find patterns distinguishing genuine vs fake reviews.

# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import os

# %%
# Load Data
df = pd.read_csv('../data/raw/fake_reviews_dataset.csv')
df.head()

# %%
# Target Distribution
plt.figure(figsize=(6, 4))
sns.countplot(x='label', data=df)
plt.title('Distribution of Fake (1) vs Genuine (0) Reviews')
plt.show()

# %%
# Rating Distribution
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x='rating', hue='label', multiple='dodge', bins=5)
plt.title('Ratings Distribution by Class')
plt.show()

# %% [markdown]
# ### Insight:
# Check if fake reviews tend to have extreme ratings (1 or 5) compared to genuine reviews.

# %%
# Text Length Analysis
df['review_len'] = df['review_text'].astype(str).apply(len)

plt.figure(figsize=(10, 6))
sns.boxplot(x='label', y='review_len', data=df)
plt.title('Review Length by Class')
plt.show()

# %%
# Word Cloud for Fake Reviews
fake_text = " ".join(df[df['label'] == 1]['review_text'].astype(str))
wordcloud_fake = WordCloud(width=800, height=400, background_color='black').generate(fake_text)

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud_fake, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud - Fake Reviews')
plt.show()

# %%
# Word Cloud for Genuine Reviews
real_text = " ".join(df[df['label'] == 0]['review_text'].astype(str))
wordcloud_real = WordCloud(width=800, height=400, background_color='white').generate(real_text)

plt.figure(figsize=(10, 5))
plt.imshow(wordcloud_real, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud - Genuine Reviews')
plt.show()
