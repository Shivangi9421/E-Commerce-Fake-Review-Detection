import streamlit as st
import pandas as pd
import joblib
import os
import sys
import plotly.express as px
from textblob import TextBlob
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import pickle
# Try importing tensorflow (optional)
try:
    from tensorflow.keras.models import load_model
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    HAS_TF = True
except ImportError:
    HAS_TF = False

# Add src to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))
from data_preprocessing import clean_text
from feature_engineering import FeaturePipeline, add_metadata_features

# Set page config
st.set_page_config(
    page_title="Fake Review Detector Pro",
    page_icon="🕵️",
    layout="wide"
)

# Load Artifacts
@st.cache_resource
def load_artifacts():
    artifacts = {}
    
    # 1. Classical Model
    try:
        if os.path.exists("models/fake_review_model.pkl"):
            artifacts['rf_model'] = joblib.load("models/fake_review_model.pkl")
            artifacts['pipeline'] = joblib.load("models/feature_pipeline.pkl")
        else:
            artifacts['rf_model'] = None
            artifacts['pipeline'] = None
    except Exception as e:
        print(f"Error loading RF model: {e}")
        artifacts['rf_model'] = None
        artifacts['pipeline'] = None
    
    # 2. LSTM Model
    if HAS_TF:
        try:
            artifacts['lstm_model'] = load_model("models/fake_review_lstm.h5")
            with open("models/tokenizer.pickle", "rb") as handle:
                artifacts['tokenizer'] = pickle.load(handle)
        except Exception:
            artifacts['lstm_model'] = None
    
    return artifacts

artifacts = load_artifacts()

def predict_lstm(text, model, tokenizer):
    """Helper to predict using LSTM."""
    # Preprocess
    seq = tokenizer.texts_to_sequences([str(text).lower()])
    padded = pad_sequences(seq, maxlen=100, padding='post', truncating='post')
    prob = model.predict(padded)[0][0] # Sigmoid output 0-1
    return 1 if prob > 0.5 else 0, prob

def main():
    st.title("🕵️ Fake Review Detector Pro")
    st.markdown("### **Advanced AI System for E-Commerce Trust**")
    
    # Sidebar
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["🔍 Single Review Analysis", "📂 Bulk Analysis (CSV)", "📊 Advanced Dashboard"])
    
    # Model Selector
    st.sidebar.divider()
    model_choice = st.sidebar.selectbox("Choose Model", ["Random Forest (Baseline)", "LSTM (Deep Learning)"])
    
    # Check model availability
    rf_model = artifacts.get('rf_model')
    lstm_model = artifacts.get('lstm_model') if HAS_TF else None
    
    if model_choice == "LSTM (Deep Learning)" and (not HAS_TF or lstm_model is None):
        st.sidebar.warning("LSTM Model invalid or TensorFlow not installed. Falling back to Random Forest.")
        model_choice = "Random Forest (Baseline)"
        
    st.sidebar.info(f"Active Model: **{model_choice}**")

    # --- PAGE 1: Single Review ---
    if page == "🔍 Single Review Analysis":
        st.header("Analyze a Single Review")
        col1, col2 = st.columns([2, 1])
        
        with col1:
            review_text = st.text_area("Review Text:", height=150, placeholder="Type a review...")
            
        with col2:
            st.metric("Model Logic", "NLP + Metadata" if "Forest" in model_choice else "Bi-Directional LSTM")
            analyze_btn = st.button("Analyze Now", type="primary", use_container_width=True)

        if analyze_btn and review_text:
            try:
                # Prediction Logic
                if model_choice == "LSTM (Deep Learning)":
                    prediction, fake_prob = predict_lstm(review_text, lstm_model, artifacts['tokenizer'])
                    genuine_prob = 1 - fake_prob
                else:
                    # RF Logic
                    if artifacts['rf_model'] is None or artifacts.get('pipeline') is None:
                        st.error("⚠️ Model not loaded! Please run `python src/train_model.py` to train the model first.")
                        st.stop()
                        
                    input_df = pd.DataFrame([{'review_text': review_text, 'rating': 5, 'verified_purchase': 1, 'helpful_votes': 0}]) # Dummy metadata for simple check
                    input_df['cleaned_text'] = input_df['review_text'].apply(clean_text)
                    input_df = add_metadata_features(input_df)
                    features = artifacts['pipeline'].transform(input_df)
                    prediction = rf_model.predict(features)[0]
                    proba = rf_model.predict_proba(features)[0]
                    fake_prob = proba[1]
                    genuine_prob = proba[0]
                
                # Result Display
                st.divider()
                r1, r2 = st.columns(2)
                with r1:
                    if prediction == 1:
                        st.error(f"## 🚨 FAKE DETECTED\n**Confidence:** {fake_prob*100:.1f}%")
                    else:
                        st.success(f"## ✅ GENUINE REVIEW\n**Trust Score:** {genuine_prob*100:.0f}/100")
                
                with r2:
                    st.write("**Analysis Insights:**")
                    sent = TextBlob(review_text).sentiment.polarity
                    st.write(f"- Sentiment Score: `{sent:.2f}`")
                    st.write(f"- Word Count: `{len(review_text.split())}`")
                    
            except Exception as e:
                st.error(f"Prediction Error: {e}")

    # --- PAGE 2: Bulk Analysis ---
    elif page == "📂 Bulk Analysis (CSV)":
        st.header("Bulk Analysis")
        st.write("Upload a CSV file containing a column named `review_text`.")
        
        uploaded_file = st.file_uploader("Upload CSV", type=["csv"])
        
        if uploaded_file:
            df = pd.read_csv(uploaded_file)
            st.write(f"Loaded {len(df)} rows.")
            
            if 'review_text' not in df.columns:
                st.error("CSV must have a 'review_text' column!")
            else:
                if st.button("Process All Reviews"):
                    progress_bar = st.progress(0)
                    
                    # Logic for Bulk Processing (using RF for speed usually, but let's use selected)
                    predictions = []
                    probs = []
                    
                    if model_choice == "LSTM (Deep Learning)":
                        # Batch prediction for LSTM
                        seq = artifacts['tokenizer'].texts_to_sequences(df['review_text'].astype(str))
                        padded = pad_sequences(seq, maxlen=100, padding='post', truncating='post')
                        batch_probs = lstm_model.predict(padded, verbose=0)
                        for p in batch_probs:
                            predictions.append(1 if p[0] > 0.5 else 0)
                            probs.append(p[0])
                    else:
                         # RF Batch
                        df['cleaned_text'] = df['review_text'].apply(clean_text)
                        # We need to ensure metadata columns exist or fill them
                        req_cols = ['rating', 'verified_purchase', 'helpful_votes']
                        for c in req_cols:
                            if c not in df.columns:
                                df[c] = 0 if c != 'rating' else 3 # Defaults
                        
                        df = add_metadata_features(df)
                        feats = artifacts['pipeline'].transform(df)
                        predictions = rf_model.predict(feats)
                        probs = rf_model.predict_proba(feats)[:, 1]
                    
                    df['prediction'] = ['FAKE' if p==1 else 'GENUINE' for p in predictions]
                    df['fake_probability'] = probs
                    progress_bar.progress(100)
                    
                    st.success("Processing Complete!")
                    st.dataframe(df[['review_text', 'prediction', 'fake_probability']].head())
                    
                    # Download
                    csv = df.to_csv(index=False)
                    st.download_button("Download Results", csv, "analyzed_reviews.csv", "text/csv")

    # --- PAGE 3: Dashboard ---
    elif page == "📊 Advanced Dashboard":
        st.header("Dataset Analytics & Visualization")
        
        data_path = os.path.join("data", "raw", "fake_reviews_dataset.csv")
        if os.path.exists(data_path):
            df_hist = pd.read_csv(data_path)
            
            # Word Clouds
            st.subheader("Word Cloud Analysis")
            wc_col1, wc_col2 = st.columns(2)
            
            with wc_col1:
                st.write("**Fake Reviews Common Words**")
                fake_text = " ".join(df_hist[df_hist['label']==1]['review_text'].astype(str))
                wc_fake = WordCloud(width=400, height=300, background_color='black', colormap='Reds').generate(fake_text)
                fig_fake, ax = plt.subplots()
                ax.imshow(wc_fake, interpolation='bilinear')
                ax.axis('off')
                st.pyplot(fig_fake)

            with wc_col2:
                st.write("**Genuine Reviews Common Words**")
                real_text = " ".join(df_hist[df_hist['label']==0]['review_text'].astype(str))
                wc_real = WordCloud(width=400, height=300, background_color='white', colormap='Greens').generate(real_text)
                fig_real, ax = plt.subplots()
                ax.imshow(wc_real, interpolation='bilinear')
                ax.axis('off')
                st.pyplot(fig_real)
            
            st.divider()
            
            # Interactive Plots
            st.subheader("Interactive Insights")
            
            df_hist['review_len'] = df_hist['review_text'].astype(str).apply(len)
            fig = px.scatter(df_hist, x='review_len', y='helpful_votes', color='label', size='rating',
                             title="Review Length vs Helpful Votes (Color=Fake/Real)",
                             hover_data=['review_text'])
            st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main()
