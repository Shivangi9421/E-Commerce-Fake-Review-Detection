import pandas as pd
import numpy as np
from faker import Faker
import random
import os

# Initialize Faker
fake = Faker()

def generate_synthetic_data(num_samples=1000):
    """Generates a synthetic dataset of reviews."""
    print(f"Generating {num_samples} synthetic reviews...")
    
    data = []
    
    # Pre-defined patterns for "fake" reviews to make them detectable by a simple model
    fake_patterns = [
        "Best product ever! Highly recommend to everyone.",
        "Amazing quality. Will buy again.",
        "Do not buy. Waste of money.",
        "Scam! terrible experience.",
        "Five stars! Amazing.",
        "Very good.",
        "Bad.",
    ]
    
    # Real-ish products
    product_ids = [f"PROD_{i:03d}" for i in range(1, 51)]
    
    for _ in range(num_samples):
        is_fake = random.choice([0, 1])  # 0: Genuine, 1: Fake
        reviewer_id = fake.uuid4()
        reviewer_name = fake.name()
        product_id = random.choice(product_ids)
        timestamp = fake.date_time_this_decade()
        
        if is_fake:
            # Fake review characteristics: 
            # - Short, generic, repetitive text
            # - Extreme ratings (1 or 5)
            review_text = random.choice(fake_patterns)
            # Add some random noise or duplication
            if random.random() > 0.5:
                review_text += " " + random.choice(fake_patterns)
            
            rating = random.choice([1, 5])
            verified_purchase = random.choice([False, True]) # Fakes might try to look verified or not
            helpful_votes = random.randint(0, 5) # Usually low engagement? Or high if bot farm. Let's say low.
        else:
            # Genuine review characteristics:
            # - More detailed (using Faker's text)
            # - varied ratings
            review_text = fake.paragraph(nb_sentences=random.randint(2, 5))
            rating = random.randint(1, 5)
            verified_purchase = random.choice([True, True, False]) # More likely to be verified
            helpful_votes = random.randint(0, 50)
            
        data.append({
            "reviewer_id": reviewer_id,
            "reviewer_name": reviewer_name,
            "product_id": product_id,
            "review_text": review_text,
            "rating": rating,
            "verified_purchase": verified_purchase,
            "helpful_votes": helpful_votes,
            "timestamp": timestamp,
            "label": is_fake
        })
        
    df = pd.DataFrame(data)
    
    # Save to CSV
    output_path = os.path.join("data", "raw", "fake_reviews_dataset.csv")
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    df.to_csv(output_path, index=False)
    print(f"Dataset saved to {output_path}")
    print(df["label"].value_counts())

if __name__ == "__main__":
    generate_synthetic_data(num_samples=2000)
