import pandas as pd
from textblob import TextBlob
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack, csr_matrix

def add_metadata_features(df):
    """Adds numerical features like review length, sentiment, etc."""
    print("Adding metadata features (sentiment, length)...")
    
    # Length features
    df['review_length_chars'] = df['review_text'].apply(len)
    df['review_length_words'] = df['review_text'].apply(lambda x: len(str(x).split()))
    
    # Sentiment analysis using TextBlob
    # Returns polarity (-1.0 to 1.0) and subjectivity (0.0 to 1.0)
    df['sentiment_polarity'] = df['review_text'].apply(lambda x: TextBlob(str(x)).sentiment.polarity)
    df['sentiment_subjectivity'] = df['review_text'].apply(lambda x: TextBlob(str(x)).sentiment.subjectivity)
    
    # Extreme rating flag
    df['is_extreme_rating'] = df['rating'].apply(lambda x: 1 if x == 1 or x == 5 else 0)
    
    # Verified purchase flag (convert to int)
    df['verified_purchase_int'] = df['verified_purchase'].astype(int)
    
    return df

class FeaturePipeline:
    def __init__(self, max_features=5000):
        self.vectorizer = TfidfVectorizer(max_features=max_features, ngram_range=(1, 2))
        
    def fit_transform(self, df):
        """Fits vectorizer and returns combined features."""
        # 1. Text Features (TF-IDF)
        text_features = self.vectorizer.fit_transform(df['cleaned_text'])
        
        # 2. Metadata Features
        # Ensure we only use the numeric columns we just created
        meta_cols = ['rating', 'review_length_chars', 'review_length_words', 
                     'sentiment_polarity', 'sentiment_subjectivity', 
                     'is_extreme_rating', 'verified_purchase_int', 'helpful_votes']
        
        meta_features = csr_matrix(df[meta_cols].values)
        
        # Combine
        combined_features = hstack([text_features, meta_features])
        
        return combined_features
    
    def transform(self, df):
        """Transforms new data using fitted vectorizer."""
        text_features = self.vectorizer.transform(df['cleaned_text'])
        
        meta_cols = ['rating', 'review_length_chars', 'review_length_words', 
                     'sentiment_polarity', 'sentiment_subjectivity', 
                     'is_extreme_rating', 'verified_purchase_int', 'helpful_votes']
        
        meta_features = csr_matrix(df[meta_cols].values)
        
        combined_features = hstack([text_features, meta_features])
        return combined_features
