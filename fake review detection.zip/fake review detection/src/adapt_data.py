import pandas as pd
import os

def adapt_dataset():
    print("Adapting Real Dataset...")
    raw_path = os.path.join("data", "raw", "real_reviews_raw.csv")
    target_path = os.path.join("data", "raw", "fake_reviews_dataset.csv")
    
    if not os.path.exists(raw_path):
        print("Raw file not found. Download failed?")
        return
        
    try:
        df = pd.read_csv(raw_path)
        print(f"Loaded {len(df)} rows from real dataset.")
        print("Columns found:", df.columns.tolist())
        
        # Mapping logic for SayamAlt dataset
        # Likely columns: 'text_', 'label', etc.
        rename_map = {}
        
        if 'text_' in df.columns:
            rename_map['text_'] = 'review_text'
        elif 'text' in df.columns:
            rename_map['text'] = 'review_text'
            
        if 'label' in df.columns:
            # Check label format
            # Usually 'CG' (Computer Generated) -> 1 (Fake), 'OR' (Original) -> 0 (Genuine)
            # OR simple 0/1
            pass 
        
        df.rename(columns=rename_map, inplace=True)
        
        # Normalize Labels if they are strings like 'OR'/'CG'
        if df['label'].dtype == 'object':
            print("Normalizing labels...")
            df['label'] = df['label'].map({'CG': 1, 'OR': 0, 'Fake': 1, 'Real': 0}).fillna(0).astype(int)
            
        # Add missing columns expected by our pipeline (fill with defaults)
        required_cols = ['reviewer_id', 'product_id', 'rating', 'verified_purchase', 'helpful_votes']
        for col in required_cols:
            if col not in df.columns:
                if col == 'rating':
                    df[col] = 4 # Default rating
                elif col == 'verified_purchase':
                    df[col] = 1
                else:
                    df[col] = 0
                    
        # Save to standard path
        df.to_csv(target_path, index=False)
        print(f"Success! Saved adapted dataset to {target_path}")
        
    except Exception as e:
        print(f"Error adapting dataset: {e}")

if __name__ == "__main__":
    adapt_dataset()
