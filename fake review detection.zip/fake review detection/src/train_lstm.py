import pandas as pd
import numpy as np
import os
import pickle
import joblib
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout, Bidirectional
from tensorflow.keras.callbacks import EarlyStopping

# Parameters
MAX_WORDS = 10000
MAX_LEN = 100
EMBEDDING_DIM = 100
EPOCHS = 5
BATCH_SIZE = 32

def train_lstm_model():
    print("Loading data for Deep Learning...")
    data_path = os.path.join("data", "raw", "fake_reviews_dataset.csv")
    if not os.path.exists(data_path):
        print("Data not found!")
        return

    df = pd.read_csv(data_path)
    
    # Simple cleaning for LSTM (Tokenization handles punctuation mostly, but consistency helps)
    df['review_text'] = df['review_text'].astype(str).str.lower()
    
    X = df['review_text'].values
    y = df['label'].values
    
    # Tokenization
    print("Tokenizing text...")
    tokenizer = Tokenizer(num_words=MAX_WORDS, oov_token="<OOV>")
    tokenizer.fit_on_texts(X)
    sequences = tokenizer.texts_to_sequences(X)
    padded_sequences = pad_sequences(sequences, maxlen=MAX_LEN, padding='post', truncating='post')
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(padded_sequences, y, test_size=0.2, random_state=42)
    
    # Build LSTM Model
    print("Building LSTM model...")
    model = Sequential([
        Embedding(MAX_WORDS, EMBEDDING_DIM, input_length=MAX_LEN),
        Bidirectional(LSTM(64, return_sequences=True)), # Bi-Directional for better context
        Dropout(0.3),
        LSTM(32),
        Dense(32, activation='relu'),
        Dropout(0.3),
        Dense(1, activation='sigmoid') # Binary classification
    ])
    
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    model.summary()
    
    # Train
    print("Training model (this may take a while)...")
    early_stop = EarlyStopping(monitor='val_loss', patience=2, restore_best_weights=True)
    
    history = model.fit(
        X_train, y_train,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        validation_data=(X_test, y_test),
        callbacks=[early_stop]
    )
    
    # Save Artifacts
    print("Saving DL artifacts...")
    os.makedirs("models", exist_ok=True)
    model.save("models/fake_review_lstm.h5") # Save Keras model
    
    # Save Tokenizer (IMPORTANT for inference)
    with open("models/tokenizer.pickle", "wb") as handle:
        pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
        
    print("LSTM Model training complete!")

if __name__ == "__main__":
    train_lstm_model()
