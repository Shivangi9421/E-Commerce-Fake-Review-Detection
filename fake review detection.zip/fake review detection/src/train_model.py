import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from xgboost import XGBClassifier

from data_preprocessing import preprocess_dataframe
from feature_engineering import add_metadata_features, FeaturePipeline

def train():
    print("Loading data...")
    # Load data
    data_path = os.path.join("data", "raw", "fake_reviews_dataset.csv")
    if not os.path.exists(data_path):
        print("Data not found. Please run generate_data.py first.")
        return
        
    df = pd.read_csv(data_path)
    
    # 1. Preprocessing
    df = preprocess_dataframe(df)
    
    # 2. Add Metadata Features
    df = add_metadata_features(df)
    
    # 3. Split Data
    X = df  # We pass the whole DF because FeaturePipeline needs multiple columns
    y = df['label']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    # 4. Feature Extraction (Fit on Train, Transform Test)
    print("Extracting features...")
    pipeline = FeaturePipeline()
    X_train_transformed = pipeline.fit_transform(X_train)
    X_test_transformed = pipeline.transform(X_test)
    
    # 5. Model Training
    print("Training Random Forest model...")
    # model = RandomForestClassifier(n_estimators=100, random_state=42)
    # Using XGBoost for better performance if possible, or Fallback to Random Forest
    model = XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
    
    model.fit(X_train_transformed, y_train)
    
    # 6. Evaluation
    print("Evaluating model...")
    y_pred = model.predict(X_test_transformed)
    
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print(f"F1 Score: {f1_score(y_test, y_pred):.4f}")
    
    # 7. Save Artifacts
    print("Saving model and vectorizer...")
    os.makedirs("models", exist_ok=True)
    
    joblib.dump(model, "models/fake_review_model.pkl")
    joblib.dump(pipeline, "models/feature_pipeline.pkl") # Save the whole custom pipeline object if possible, or just the vectorizer
    # Note: Pickling certain custom classes can be tricky if the script structure changes. 
    # For safety, we will pickle the internal vectorizer separately if needed, 
    # but pickling the pipeline object `pipeline` is easier if we import the class in the app correctly.
    
    print("Training complete. Artifacts saved in 'models/' directory.")

if __name__ == "__main__":
    train()
