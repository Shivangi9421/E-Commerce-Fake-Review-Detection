import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Download NLTK data (run once)
try:
    nltk.data.find('corpora/stopwords')
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('stopwords')
    nltk.download('wordnet')
    nltk.download('omw-1.4')

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

def clean_text(text):
    """
    Cleans review text:
    - Lowercase
    - Remove HTML tags
    - Remove URLs
    - Remove special chars/punctuation
    - Remove stopwords
    - Lemmatization
    """
    if not isinstance(text, str):
        return ""
    
    # Lowercase
    text = text.lower()
    
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    
    # Remove URLs
    text = re.sub(r'http\S+|www\S+|https\S+', '', text, flags=re.MULTILINE)
    
    # Remove punctuation and numbers (keeping only letters)
    text = re.sub(r'[^a-z\s]', '', text)
    
    # Tokenize and remove stopwords + lemmatize
    tokens = text.split()
    clean_tokens = [lemmatizer.lemmatize(token) for token in tokens if token not in stop_words]
    
    return " ".join(clean_tokens)

def preprocess_dataframe(df, text_column='review_text'):
    """Applies cleaning to the dataframe."""
    print("Preprocessing text...")
    df['cleaned_text'] = df[text_column].apply(clean_text)
    return df
